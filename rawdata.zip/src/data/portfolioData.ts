export interface TimelineItem {
  id: string;
  year: string;
  date: string;
  title: string;
  company: string;
  role: string;
  category: 'work' | 'education' | 'milestone';
  description: string;
  highlights: string[];
  technologies: string[];
  iconName: string;
}

export interface Project {
  id: string;
  title: string;
  tagline: string;
  description: string;
  fullDescription: string;
  image: string;
  tags: string[];
  demoUrl: string;
  githubUrl: string;
  featured: boolean;
  category: 'Research' | 'Simulation' | 'Astronomy' | 'Data';
}

export interface SkillCategory {
  title: string;
  icon: string;
  skills: { name: string; level: number; iconColor: string }[];
}

export const PERSONAL_INFO = {
  name: 'Siddharth S',
  title: 'Physics Undergraduate | Astronomy & Instrumentation Enthusiast',
  tagline:
    'Undergraduate physics student focused on astronomy, detector physics, observational astrophysics, and scientific computing.',
  location: 'Manipal, India',
  bio:
    'I am a Bachelor of Physics student at the Manipal Institute of Applied Physics, MAHE. My academic interests include astronomy, astronomical instrumentation, detector physics, and observational astrophysics. I have experience working with high-energy particle simulations for X-ray detector materials using FLUKA, and I am building strong foundations in Python-based scientific computing and GEANT4 for future research in astronomical instrumentation and observational astronomy.',
  email: 'siddharthsadhan@gmail.com',
  website: 'www.siddharth.qzz.io',
  github: '#',
  linkedin: '#',
  twitter: '#',
  resumeUrl: '#',
  stats: [
    { label: 'Current Degree', value: 'B.Phys' },
    { label: 'CGPA', value: '7.16' },
    { label: 'Research Areas', value: '4+' },
    { label: 'Workshops & Series', value: '6+' },
  ],
};

export const TIMELINE_DATA: TimelineItem[] = [
  {
    id: 't1',
    year: 'Oct 2025 - Present',
    date: 'Oct 2025 - Present',
    title: 'Simulation of High-Energy Particles for X-Ray Telescope',
    company: 'Manipal Center for Natural Sciences',
    role: 'Research Work',
    category: 'work',
    description:
      'Working on simulations for detector materials used in CCDs for X-ray telescopes and studying the focusing of X-rays under faculty supervision.',
    highlights: [
      'Formulated and implemented simulations for a variety of detector materials used in X-ray telescope CCDs.',
      'Computed results using FLUKA, the general-purpose Monte Carlo code developed at CERN.',
      'Studied transport and interaction of particles and nuclei in matter for detector-focused research.',
    ],
    technologies: ['FLUKA', 'Particle Simulation', 'X-Ray Detectors', 'CCD', 'Scientific Computing'],
    iconName: 'Briefcase',
  },
  {
    id: 't2',
    year: 'Dec 2025',
    date: 'Dec 2025',
    title: 'Workshop Series',
    company: 'Indian Center for Space Science, Kolkata',
    role: 'Workshop',
    category: 'milestone',
    description:
      'Participated in a technical workshop series covering astronomy, signal propagation, black hole modelling, and detector simulation.',
    highlights: [
      'Optical Astronomy Software and Data Analysis.',
      'Observation and model fitting of stellar and supermassive black holes.',
      'Simulation of radio signal propagation: ionosphere as space detector.',
      'Balloon-borne astronomy and simulation with GEANT4.',
    ],
    technologies: ['GEANT4', 'Astronomy Data Analysis', 'Signal Propagation', 'Black Hole Modelling'],
    iconName: 'Award',
  },
  {
    id: 't3',
    year: 'July 2025',
    date: 'July 2025',
    title: 'Comprehensive Review Paper on Varying Light Curves in Eclipsing Binary Systems of Two Cepheids',
    company: 'Under Internal Review',
    role: 'Manuscript',
    category: 'milestone',
    description:
      'Investigated systematic photometric effects in Cepheid binaries and their impact on Hubble constant precision.',
    highlights: [
      'Focused on varying light curves in eclipsing binary systems of two Cepheids.',
      'Studied how systematic effects in Cepheid photometry influence the precision of Hubble constant measurements.',
      'Developed research and scientific writing experience through review-based analysis.',
    ],
    technologies: ['Photometry', 'Cepheid Variables', 'Astrophysics', 'Scientific Writing'],
    iconName: 'Award',
  },
  {
    id: 't4',
    year: 'July 2025',
    date: 'July 2025',
    title: 'Intro2Astro Workshops',
    company: 'Independent Speakers Around the World',
    role: 'Workshop',
    category: 'milestone',
    description:
      'Attended astronomy-focused workshop sessions led by international speakers, including Prof. Fei Dai of the University of Hawaiʻi at Mānoa.',
    highlights: [
      'Learned important techniques involving utilization of lightcurves, scipy, and numpy.',
      'Explored exoplanetary atmospheres and model fitting with velocity data.',
      'Strengthened foundations in modern astronomy research workflows and computational tools.',
    ],
    technologies: ['Python', 'NumPy', 'SciPy', 'Light Curves', 'Exoplanet Atmospheres'],
    iconName: 'Award',
  },
  {
    id: 't5',
    year: 'June 2025',
    date: 'June 2025',
    title: 'Summer Internship and Workshop',
    company: 'EduFabrica in association with IIT Madras',
    role: 'Internship',
    category: 'work',
    description:
      'Completed a summer internship program with astronomy classes and wrote a review paper on varying light curves in eclipsing binary systems.',
    highlights: [
      'Attended 3 weeks of classes covering basic astronomy, relativity, astrometry, and astrobiology.',
      'Prepared a review paper on varying light curves in eclipsing binary systems of two Cepheids.',
      'Concluded that improved handling of systematic effects in Cepheid photometry enhances Hubble constant precision.',
    ],
    technologies: ['Astronomy', 'Astrometry', 'Astrobiology', 'Relativity', 'Research Review'],
    iconName: 'Briefcase',
  },
  {
    id: 't6',
    year: 'Dec 2024 - Present',
    date: 'Dec 2024 - Present',
    title: 'Astronomy / Astrophysics Lecture Series',
    company: 'Manipal Center for Natural Sciences',
    role: 'Lecture Series',
    category: 'milestone',
    description:
      'Regularly participating in astronomy and astrophysics lecture sessions to deepen theoretical and practical understanding.',
    highlights: [
      'Attend weekly lectures on astronomy every Wednesday at Manipal Center for Natural Sciences, MAHE.',
      'Participate in advanced discussions on core and emerging topics in astronomy and astrophysics.',
      'Engage with research-level ideas in observational techniques, data interpretation, and instrumentation.',
      'Use lecture content to strengthen foundations for simulation and data analysis work.',
    ],
    technologies: ['Astronomy', 'Astrophysics', 'Observation', 'Instrumentation', 'Data Interpretation'],
    iconName: 'Terminal',
  },
  {
    id: 't7',
    year: 'Dec 2024',
    date: 'Dec 2024',
    title: 'Winter School on Astronomical Calculations with Python',
    company: 'IAPT Mumbai Division in association with Kritikka - The Astronomy Club, IITB',
    role: 'Winter School',
    category: 'milestone',
    description:
      'Participated in a student-oriented program focused on basic astronomy and computation with Python.',
    highlights: [
      'Conducted by IAPT Mumbai with Gargi College and Wilson College, Mumbai.',
      'Focused on teaching students foundational astronomy and computational methods.',
      'Strengthened Python-based astronomy calculation skills and scientific problem solving.',
    ],
    technologies: ['Python', 'Astronomical Calculations', 'Computation', 'Basic Astronomy'],
    iconName: 'Code',
  },
  {
    id: 't8',
    year: 'Aug 2024 - Present',
    date: 'Aug 2024 - Present',
    title: 'Bachelor of Physics',
    company: 'Manipal Institute of Applied Physics, MAHE',
    role: 'Education',
    category: 'education',
    description:
      'Pursuing a Bachelor of Physics with a major in Physics and a minor in Mathematics.',
    highlights: [
      'Bachelor of Physics student at MAHE.',
      'Major in Physics.',
      'Minor in Mathematics.',
      'Current CGPA: 7.16.',
    ],
    technologies: ['Physics', 'Mathematics', 'Scientific Computing', 'Astrophysics'],
    iconName: 'GraduationCap',
  },
];

export const PROJECTS_DATA: Project[] = [
  {
    id: 'p1',
    title: 'X-Ray Detector Material Simulation',
    tagline: 'Simulating detector materials for X-ray telescope CCD applications.',
    description:
      'A research-oriented simulation effort focused on understanding detector material behavior for X-ray telescopes.',
    fullDescription:
      'This work involves formulating and implementing simulations for materials used as detectors in CCDs for X-ray telescopes. The research uses FLUKA to compute particle transport and interaction in matter, with a long-term goal of contributing to detector physics and astronomical instrumentation.',
    image: 'https://images.unsplash.com/photo-1462331940025-496dfbfc7564?auto=format&fit=crop&w=1200&q=80',
    tags: ['FLUKA', 'X-Ray Telescope', 'CCD', 'Detector Physics', 'Simulation'],
    demoUrl: '#timeline',
    githubUrl: '#',
    featured: true,
    category: 'Simulation',
  },
  {
    id: 'p2',
    title: 'Cepheid Light Curve Review Paper',
    tagline: 'Reviewing photometric systematics in eclipsing binary Cepheid systems.',
    description:
      'A manuscript project examining varying light curves and their effect on Hubble constant precision.',
    fullDescription:
      'This review paper investigates systematic photometric effects in eclipsing binary systems of two Cepheids. A key conclusion is that improved treatment of systematic effects in Cepheid photometry can enhance the precision of Hubble constant measurements.',
    image: 'https://images.unsplash.com/photo-1446776877081-d282a0f896e2?auto=format&fit=crop&w=1200&q=80',
    tags: ['Photometry', 'Cepheids', 'Astrophysics', 'Research', 'Hubble Constant'],
    demoUrl: '#timeline',
    githubUrl: '#',
    featured: true,
    category: 'Research',
  },
  {
    id: 'p3',
    title: 'Astronomy Python Calculations',
    tagline: 'Applying Python to astronomy calculations and scientific workflows.',
    description:
      'Built foundational computational methods for astronomy through workshops and practical problem solving.',
    fullDescription:
      'Through winter school and astronomy workshops, I developed practical familiarity with Python-based astronomical calculations and scientific computing. This includes exposure to numerical methods, foundational analysis tasks, and computational thinking relevant to astrophysics research.',
    image: 'https://images.unsplash.com/photo-1515879218367-8466d910aaa4?auto=format&fit=crop&w=1200&q=80',
    tags: ['Python', 'Astronomy', 'Computation', 'NumPy', 'Scientific Computing'],
    demoUrl: '#skills',
    githubUrl: '#',
    featured: true,
    category: 'Data',
  },
  {
    id: 'p4',
    title: 'Lecture Notes & Astrophysics Learning Track',
    tagline: 'Consistent self-driven study through astronomy and astrophysics lecture series.',
    description:
      'A structured ongoing learning journey across observational methods, instrumentation, and data interpretation.',
    fullDescription:
      'By regularly participating in lecture series at Manipal Center for Natural Sciences, I have built stronger foundations in astronomy, astrophysics, observational techniques, and scientific interpretation. This ongoing learning supports my simulation and instrumentation goals.',
    image: 'https://images.unsplash.com/photo-1502134249126-9f3755a50d78?auto=format&fit=crop&w=1200&q=80',
    tags: ['Astrophysics', 'Observation', 'Instrumentation', 'Learning', 'Data Interpretation'],
    demoUrl: '#timeline',
    githubUrl: '#',
    featured: false,
    category: 'Astronomy',
  },
];

export const SKILL_CATEGORIES: SkillCategory[] = [
  {
    title: 'Programming',
    icon: 'Layout',
    skills: [
      { name: 'Python', level: 85, iconColor: '#22d3ee' },
      { name: 'MATLAB', level: 60, iconColor: '#ffffff' },
      { name: 'Basic JavaScript', level: 45, iconColor: '#eab308' },
      { name: 'Basic C and C++', level: 45, iconColor: '#eab308' },
    ],
  },
  {
    title: 'Simulation & Scientific Tools',
    icon: 'Server',
    skills: [
      { name: 'FLUKA', level: 80, iconColor: '#22d3ee' },
      { name: 'IRAF', level: 60, iconColor: '#ffffff' },
      { name: 'PyRAF', level: 60, iconColor: '#ffffff' },
      { name: 'Basic GEANT4 Simulation', level: 50, iconColor: '#eab308' },
    ],
  },
  {
    title: 'Astronomy Data Techniques',
    icon: 'Cloud',
    skills: [
      { name: 'Photometry', level: 75, iconColor: '#22d3ee' },
      { name: 'Astrometry', level: 70, iconColor: '#ffffff' },
      { name: 'Light Curve Analysis', level: 68, iconColor: '#eab308' },
      { name: 'Data Analysis Workflows', level: 72, iconColor: '#22d3ee' },
    ],
  },
  {
    title: 'Computing & Technical Foundations',
    icon: 'Cpu',
    skills: [
      { name: 'Unix / Linux', level: 70, iconColor: '#ffffff' },
      { name: 'Scientific Computing', level: 75, iconColor: '#22d3ee' },
      { name: 'Basic Instrumentation', level: 65, iconColor: '#eab308' },
      { name: 'Research Workflows', level: 72, iconColor: '#ffffff' },
    ],
  },
];

export const TESTIMONIALS = [
  {
    id: 'test1',
    name: 'Academic Focus',
    role: 'Astronomy, Instrumentation, Detector Physics',
    avatar: 'https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=200&h=200&q=80',
    content:
      'My core interests lie in astronomy, astronomical instrumentation, detector physics, and observational astrophysics, with the long-term goal of pursuing PhD research in these areas.',
    company: 'Student Research Statement',
  },
  {
    id: 'test2',
    name: 'Scientific Computing',
    role: 'Python, FLUKA, GEANT4',
    avatar: 'https://images.unsplash.com/photo-1517976547714-720226b864c1?auto=format&fit=crop&w=200&h=200&q=80',
    content:
      'I am building my skills in Python-based scientific computing and simulation tools through workshops, lecture series, and applied research experience.',
    company: 'Technical Direction',
  },
  {
    id: 'test3',
    name: 'Research Goal',
    role: 'Observational Astronomy',
    avatar: 'https://images.unsplash.com/photo-1465101046530-73398c7f28ca?auto=format&fit=crop&w=200&h=200&q=80',
    content:
      'My aim is to contribute to astronomical instrumentation and observational astronomy through simulation, data analysis, and sustained academic research.',
    company: 'Career Objective',
  },
];
