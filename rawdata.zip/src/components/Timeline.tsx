import React, { useState, useMemo } from 'react';
import { TIMELINE_DATA } from '../data/portfolioData';
import { Briefcase, GraduationCap, Award, Code, Terminal, ChevronDown, ChevronUp, Calendar, ArrowUpDown, Filter } from 'lucide-react';

export const Timeline: React.FC = () => {
  const [activeCategory, setActiveCategory] = useState<'all' | 'work' | 'education' | 'milestone'>('all');
  const [sortOrder, setSortOrder] = useState<'newest' | 'oldest'>('newest');
  const [expandedIds, setExpandedIds] = useState<Record<string, boolean>>({
    t1: true,
    t2: true,
  });

  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'Briefcase': return <Briefcase className="w-5 h-5 text-yellow-400" />;
      case 'GraduationCap': return <GraduationCap className="w-5 h-5 text-cyan-400" />;
      case 'Award': return <Award className="w-5 h-5 text-yellow-400" />;
      case 'Code': return <Code className="w-5 h-5 text-cyan-400" />;
      case 'Terminal': return <Terminal className="w-5 h-5 text-white" />;
      default: return <Briefcase className="w-5 h-5 text-yellow-400" />;
    }
  };

  const toggleExpand = (id: string) => {
    setExpandedIds(prev => ({ ...prev, [id]: !prev[id] }));
  };

  const filteredData = useMemo(() => {
    let items = TIMELINE_DATA;
    if (activeCategory !== 'all') {
      items = items.filter(item => item.category === activeCategory);
    }
    return [...items].sort((a, b) => {
      const indexA = parseInt(a.id.replace('t', ''));
      const indexB = parseInt(b.id.replace('t', ''));
      return sortOrder === 'newest' ? indexA - indexB : indexB - indexA;
    });
  }, [activeCategory, sortOrder]);

  const categories = [
    { label: 'All Events', value: 'all' },
    { label: 'Work Experience', value: 'work' },
    { label: 'Education', value: 'education' },
    { label: 'Milestones', value: 'milestone' }
  ];

  return (
    <section id="timeline" className="py-24 relative bg-[#050505]/45 backdrop-blur-[1px]">
      {/* Ambient background glow */}
      <div className="absolute top-1/3 right-10 w-96 h-96 bg-yellow-500/10 blur-[160px] rounded-full pointer-events-none -z-10" />
      <div className="absolute bottom-10 left-10 w-80 h-80 bg-cyan-500/10 blur-[150px] rounded-full pointer-events-none -z-10" />

      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-zinc-900 border border-zinc-800 text-yellow-400 text-xs font-bold uppercase tracking-widest mb-4">
            <span>02 // Career Journey</span>
          </div>
          <h2 className="text-3xl sm:text-5xl font-extrabold text-white tracking-tight mb-4">
            What I Was Doing & When
          </h2>
          <p className="text-lg text-zinc-400">
            A chronological timeline of my engineering career, educational milestones, and key technical achievements.
          </p>
        </div>

        {/* Filter & Sort Controls */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 mb-16 p-3 bg-zinc-950/90 border border-zinc-800 rounded-2xl backdrop-blur-md shadow-lg">
          <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto">
            <div className="hidden md:flex items-center gap-2 px-3 text-zinc-400 text-xs font-['Fira_Code',monospace] uppercase font-bold">
              <Filter className="w-3.5 h-3.5 text-yellow-400" />
              <span>Filter:</span>
            </div>
            {categories.map((cat) => (
              <button
                key={cat.value}
                onClick={() => setActiveCategory(cat.value as any)}
                className={`px-4 py-2 rounded-xl text-xs sm:text-sm transition-all cursor-pointer ${
                  activeCategory === cat.value
                    ? 'bg-gradient-to-r from-yellow-500 via-amber-400 to-cyan-500 text-black font-extrabold shadow-md shadow-yellow-500/20'
                    : 'text-zinc-400 hover:text-white hover:bg-zinc-900/80 font-medium'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>

          <button
            onClick={() => setSortOrder(sortOrder === 'newest' ? 'oldest' : 'newest')}
            className="flex items-center justify-center gap-2 px-4 py-2 w-full sm:w-auto bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 rounded-xl text-zinc-300 hover:text-white text-xs sm:text-sm font-bold transition-colors cursor-pointer"
          >
            <ArrowUpDown className="w-4 h-4 text-cyan-400" />
            <span>{sortOrder === 'newest' ? 'Newest First' : 'Oldest First'}</span>
          </button>
        </div>

        {/* Timeline Flow */}
        <div className="relative">
          {/* Vertical Guide Line */}
          <div className="absolute left-4 sm:left-1/2 top-4 bottom-4 -translate-x-1/2 w-1 bg-gradient-to-b from-yellow-500 via-cyan-500 to-zinc-900 rounded-full" />

          <div className="flex flex-col gap-12">
            {filteredData.map((item, index) => {
              const isEven = index % 2 === 0;
              const isExpanded = !!expandedIds[item.id];

              return (
                <div 
                  key={item.id}
                  className={`relative flex flex-col sm:flex-row items-start ${
                    isEven ? 'sm:flex-row-reverse' : ''
                  } group`}
                >
                  {/* Central Node Marker */}
                  <div className="absolute left-4 sm:left-1/2 -translate-x-1/2 top-6 w-11 h-11 rounded-2xl bg-black border-2 border-yellow-500 flex items-center justify-center z-10 shadow-xl shadow-yellow-500/20 group-hover:scale-110 group-hover:bg-yellow-500 transition-all duration-300 group-hover:border-white">
                    {getIcon(item.iconName)}
                  </div>

                  {/* Content Box */}
                  <div className={`w-full pl-14 sm:pl-0 sm:w-[calc(50%-2.5rem)] ${
                    isEven ? 'sm:pr-10' : 'sm:pl-10'
                  }`}>
                    <div className="bg-zinc-950/90 border border-zinc-900 hover:border-yellow-500/50 p-6 sm:p-8 rounded-3xl shadow-2xl backdrop-blur-xl transition-all duration-300 hover:shadow-yellow-500/10">
                      
                      {/* Year / Date Tag */}
                      <div className="flex items-center justify-between gap-2 mb-3">
                        <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-zinc-900 border border-yellow-500/40 text-yellow-300 text-xs font-['Fira_Code',monospace] font-bold shadow-inner">
                          <Calendar className="w-3 h-3 text-cyan-400" />
                          {item.year}
                        </span>
                        
                        <span className={`text-xs px-2.5 py-0.5 rounded-md uppercase font-bold tracking-wider ${
                          item.category === 'work' ? 'bg-yellow-500/10 text-yellow-400 border border-yellow-500/20' :
                          item.category === 'education' ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/20' :
                          'bg-white/10 text-white border border-white/20'
                        }`}>
                          {item.role}
                        </span>
                      </div>

                      {/* Title & Company */}
                      <h3 className="text-xl sm:text-2xl font-extrabold text-white mb-1 group-hover:text-yellow-400 transition-colors">
                        {item.title}
                      </h3>
                      <h4 className="text-base text-zinc-400 font-bold mb-4">
                        {item.company}
                      </h4>

                      {/* Brief Description */}
                      <p className="text-zinc-300 text-sm leading-relaxed mb-6">
                        {item.description}
                      </p>

                      {/* Expand / Collapse Button */}
                      <button
                        onClick={() => toggleExpand(item.id)}
                        className="flex items-center gap-1.5 text-xs font-bold text-cyan-400 hover:text-cyan-300 transition-colors mb-4 focus:outline-none cursor-pointer"
                      >
                        <span>{isExpanded ? 'Hide Key Highlights' : 'View Key Highlights'}</span>
                        {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                      </button>

                      {/* Expanded Highlights */}
                      {isExpanded && (
                        <div className="mb-6 pt-4 border-t border-zinc-900 animate-fadeIn">
                          <ul className="space-y-2.5 text-sm text-zinc-300">
                            {item.highlights.map((highlight, hIdx) => (
                              <li key={hIdx} className="flex items-start gap-2.5">
                                <span className="w-1.5 h-1.5 rounded-full bg-yellow-400 mt-2 shrink-0 shadow-sm shadow-yellow-500" />
                                <span className="leading-relaxed font-normal">{highlight}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      )}

                      {/* Technologies Pills */}
                      <div className="flex flex-wrap gap-2 pt-4 border-t border-zinc-900">
                        {item.technologies.map((tech, tIdx) => (
                          <span
                            key={tIdx}
                            className="px-2.5 py-1 rounded-lg bg-zinc-900 text-zinc-300 font-['Fira_Code',monospace] text-xs font-medium hover:text-white hover:bg-zinc-800 transition-colors border border-zinc-800/80"
                          >
                            {tech}
                          </span>
                        ))}
                      </div>

                    </div>
                  </div>

                </div>
              );
            })}
          </div>

          {filteredData.length === 0 && (
            <div className="text-center py-16 bg-zinc-950/80 rounded-3xl border border-zinc-900">
              <p className="text-zinc-400">No timeline events match the selected filter.</p>
              <button 
                onClick={() => setActiveCategory('all')} 
                className="mt-4 px-4 py-2 bg-yellow-500/20 text-yellow-400 font-bold rounded-lg text-sm cursor-pointer"
              >
                Reset Filters
              </button>
            </div>
          )}

        </div>

      </div>
    </section>
  );
};
