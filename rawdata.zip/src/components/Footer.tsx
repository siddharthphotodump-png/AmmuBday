import React from 'react';
import { PERSONAL_INFO } from '../data/portfolioData';

export const Footer: React.FC = () => {
  return (
    <footer className="border-t border-zinc-900 bg-zinc-950/55 py-10 backdrop-blur-[1px]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col md:flex-row items-center justify-between gap-4 text-sm">
        <div className="text-white font-medium">{PERSONAL_INFO.name}</div>
        <div className="text-zinc-500 text-center">Physics • Astronomy • Instrumentation • Scientific Computing</div>
        <div className="text-zinc-500">© {new Date().getFullYear()}</div>
      </div>
    </footer>
  );
};
