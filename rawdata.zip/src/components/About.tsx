import React from 'react';
import { PERSONAL_INFO } from '../data/portfolioData';
import { Telescope, Cpu, Microscope, BookMarked } from 'lucide-react';

export const About: React.FC = () => {
  const areas = [
    {
      icon: Telescope,
      title: 'Astronomy',
      description: 'Academic interest in astronomy and observational astrophysics, with sustained involvement in lectures and workshops.',
      color: 'text-yellow-400',
    },
    {
      icon: Microscope,
      title: 'Detector Physics',
      description: 'Research curiosity around detector materials, X-ray telescope systems, and instrumentation-related study.',
      color: 'text-cyan-400',
    },
    {
      icon: Cpu,
      title: 'Scientific Computing',
      description: 'Hands-on exposure to FLUKA, Python, and computational workflows used in simulation and astronomy-related analysis.',
      color: 'text-white',
    },
    {
      icon: BookMarked,
      title: 'Research Learning',
      description: 'Building a foundation through manuscripts, workshops, lecture series, and guided academic exploration.',
      color: 'text-yellow-400',
    },
  ];

  return (
    <section id="about" className="py-24 border-y border-zinc-900 bg-black/35 backdrop-blur-[1px]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full border border-zinc-800 bg-zinc-950 text-cyan-400 text-xs font-semibold uppercase tracking-widest mb-4">
            01 // About
          </div>
          <h2 className="text-3xl sm:text-5xl font-bold text-white tracking-tight mb-6">
            Academic Interests & Research Direction
          </h2>
          <p className="text-lg text-zinc-300 leading-relaxed">{PERSONAL_INFO.bio}</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {areas.map((area, idx) => {
            const Icon = area.icon;
            return (
              <div key={idx} className="rounded-3xl border border-zinc-800 bg-zinc-950 p-6">
                <div className={`w-12 h-12 rounded-2xl border border-zinc-800 bg-black flex items-center justify-center mb-5 ${area.color}`}>
                  <Icon className="w-6 h-6" />
                </div>
                <h3 className="text-lg font-semibold text-white mb-2">{area.title}</h3>
                <p className="text-sm text-zinc-400 leading-relaxed">{area.description}</p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
