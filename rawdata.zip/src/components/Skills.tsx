import React from 'react';
import { SKILL_CATEGORIES } from '../data/portfolioData';
import { Layout, Server, Cloud, Cpu } from 'lucide-react';

export const Skills: React.FC = () => {
  const getCategoryIcon = (iconName: string) => {
    switch (iconName) {
      case 'Layout':
        return <Layout className="w-5 h-5 text-cyan-400" />;
      case 'Server':
        return <Server className="w-5 h-5 text-yellow-400" />;
      case 'Cloud':
        return <Cloud className="w-5 h-5 text-white" />;
      default:
        return <Cpu className="w-5 h-5 text-cyan-400" />;
    }
  };

  return (
    <section id="skills" className="py-24 bg-black/35 border-t border-zinc-900 backdrop-blur-[1px]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full border border-zinc-800 bg-zinc-950 text-cyan-400 text-xs font-semibold uppercase tracking-widest mb-4">
            04 // Skills
          </div>
          <h2 className="text-3xl sm:text-5xl font-bold text-white mb-4">Key Skills</h2>
          <p className="text-lg text-zinc-400">
            Programming, simulation tools, astronomy data techniques, and computing foundations gathered from coursework, workshops, and research exposure.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {SKILL_CATEGORIES.map((category, idx) => (
            <div key={idx} className="rounded-3xl border border-zinc-800 bg-zinc-950 p-8">
              <div className="flex items-center gap-3 mb-8 pb-4 border-b border-zinc-800">
                <div className="w-10 h-10 rounded-xl border border-zinc-800 bg-black flex items-center justify-center">
                  {getCategoryIcon(category.icon)}
                </div>
                <h3 className="text-xl font-semibold text-white">{category.title}</h3>
              </div>

              <div className="space-y-5">
                {category.skills.map((skill, skillIdx) => (
                  <div key={skillIdx}>
                    <div className="flex items-center justify-between mb-2 text-sm">
                      <span className="text-zinc-200">{skill.name}</span>
                      <span className="text-zinc-500">{skill.level}%</span>
                    </div>
                    <div className="w-full h-2 rounded-full bg-black border border-zinc-800 overflow-hidden">
                      <div
                        className="h-full"
                        style={{ width: `${skill.level}%`, backgroundColor: skill.iconColor }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
