import React, { useState } from 'react';
import { PERSONAL_INFO } from '../data/portfolioData';
import { Mail, MapPin, Globe, Copy, Check, Phone } from 'lucide-react';

const InstagramIcon: React.FC<{ className?: string }> = ({ className = 'w-5 h-5' }) => (
  <svg viewBox="0 0 24 24" fill="currentColor" className={className}>
    <path d="M7.75 2h8.5A5.75 5.75 0 0 1 22 7.75v8.5A5.75 5.75 0 0 1 16.25 22h-8.5A5.75 5.75 0 0 1 2 16.25v-8.5A5.75 5.75 0 0 1 7.75 2m-.25 2A3.5 3.5 0 0 0 4 7.5v9A3.5 3.5 0 0 0 7.5 20h9a3.5 3.5 0 0 0 3.5-3.5v-9A3.5 3.5 0 0 0 16.5 4h-9m9.75 1.5a1.25 1.25 0 1 1 0 2.5 1.25 1.25 0 0 1 0-2.5M12 7a5 5 0 1 1 0 10 5 5 0 0 1 0-10m0 2a3 3 0 1 0 0 6 3 3 0 0 0 0-6" />
  </svg>
);

export const Contact: React.FC = () => {
  const [copied, setCopied] = useState(false);

  const handleCopyEmail = () => {
    navigator.clipboard.writeText(PERSONAL_INFO.email);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <section id="contact" className="py-24 bg-black/35 backdrop-blur-[1px]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full border border-zinc-800 bg-zinc-950 text-cyan-400 text-xs font-semibold uppercase tracking-widest mb-4">
            06 // Contact
          </div>
          <h2 className="text-3xl sm:text-5xl font-bold text-white mb-4">Get in Touch</h2>
          <p className="text-lg text-zinc-400">
            If you would like to connect regarding research, academic collaboration, or scientific computing, you can reach me directly below.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 max-w-5xl mx-auto">
          <div className="rounded-3xl border border-zinc-800 bg-zinc-950 p-8">
            <h3 className="text-2xl font-semibold text-white mb-6">Contact Details</h3>

            <div className="space-y-5">
              <div className="flex items-start gap-4">
                <div className="w-11 h-11 rounded-xl border border-zinc-800 bg-black flex items-center justify-center">
                  <Mail className="w-5 h-5 text-yellow-400" />
                </div>
                <div className="flex-1">
                  <div className="text-sm text-zinc-500 mb-1">Email</div>
                  <div className="text-white break-all">{PERSONAL_INFO.email}</div>
                </div>
                <button
                  onClick={handleCopyEmail}
                  className="p-2 rounded-lg border border-zinc-800 bg-black text-zinc-300 hover:text-white"
                >
                  {copied ? <Check className="w-4 h-4 text-cyan-400" /> : <Copy className="w-4 h-4" />}
                </button>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-11 h-11 rounded-xl border border-zinc-800 bg-black flex items-center justify-center">
                  <Phone className="w-5 h-5 text-cyan-400" />
                </div>
                <div>
                  <div className="text-sm text-zinc-500 mb-1">Phone</div>
                  <a href="tel:+919150461762" className="text-white hover:text-cyan-400 transition-colors">+91 91504 61762</a>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-11 h-11 rounded-xl border border-zinc-800 bg-black flex items-center justify-center">
                  <InstagramIcon className="w-5 h-5 text-yellow-400" />
                </div>
                <div>
                  <div className="text-sm text-zinc-500 mb-1">Instagram</div>
                  <a href="https://www.instagram.com/pxlbyt/" target="_blank" rel="noopener noreferrer" className="text-white hover:text-yellow-400 transition-colors">pxlbyt</a>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-11 h-11 rounded-xl border border-zinc-800 bg-black flex items-center justify-center">
                  <Globe className="w-5 h-5 text-cyan-400" />
                </div>
                <div>
                  <div className="text-sm text-zinc-500 mb-1">Website</div>
                  <div className="text-white">{PERSONAL_INFO.website}</div>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-11 h-11 rounded-xl border border-zinc-800 bg-black flex items-center justify-center">
                  <MapPin className="w-5 h-5 text-yellow-400" />
                </div>
                <div>
                  <div className="text-sm text-zinc-500 mb-1">Location</div>
                  <div className="text-white">{PERSONAL_INFO.location}</div>
                </div>
              </div>
            </div>
          </div>

          <div className="rounded-3xl border border-zinc-800 bg-zinc-950 p-8">
            <h3 className="text-2xl font-semibold text-white mb-6">Academic Focus</h3>
            <div className="space-y-4 text-zinc-300 leading-relaxed">
              <p>
                I am especially interested in astronomy, astronomical instrumentation, detector physics, and observational astrophysics.
              </p>
              <p>
                My current training includes workshop participation, lecture series engagement, scientific computing, and simulation work using tools such as FLUKA.
              </p>
              <p>
                My long-term goal is to pursue PhD research in astronomical instrumentation and observational astronomy.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
