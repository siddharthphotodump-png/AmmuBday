import React from 'react';
import { Project } from '../data/portfolioData';
import { X } from 'lucide-react';

interface ProjectModalProps {
  project: Project | null;
  onClose: () => void;
}

export const ProjectModal: React.FC<ProjectModalProps> = ({ project, onClose }) => {
  if (!project) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
      <div className="w-full max-w-3xl max-h-[90vh] overflow-y-auto rounded-3xl border border-zinc-800 bg-zinc-950">
        <div className="relative">
          <img src={project.image} alt={project.title} className="w-full h-64 object-cover" />
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-2 rounded-full bg-black/70 text-white border border-zinc-700"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-8 text-left">
          <div className="text-xs uppercase tracking-wider text-cyan-400 mb-2">{project.category}</div>
          <h2 className="text-3xl font-bold text-white mb-3">{project.title}</h2>
          <p className="text-lg text-zinc-300 mb-6">{project.tagline}</p>

          <div className="border-t border-zinc-800 pt-6 mb-6">
            <h3 className="text-sm uppercase tracking-wider text-yellow-400 mb-3">Overview</h3>
            <p className="text-zinc-300 leading-relaxed">{project.fullDescription}</p>
          </div>

          <div className="border-t border-zinc-800 pt-6">
            <h3 className="text-sm uppercase tracking-wider text-yellow-400 mb-3">Keywords</h3>
            <div className="flex flex-wrap gap-2">
              {project.tags.map((tag, idx) => (
                <span key={idx} className="px-3 py-1.5 rounded-full border border-zinc-800 text-sm text-zinc-300">
                  {tag}
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
