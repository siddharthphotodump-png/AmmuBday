import React from 'react';
import { TESTIMONIALS } from '../data/portfolioData';
import { Quote } from 'lucide-react';

export const Testimonials: React.FC = () => {
  return (
    <section id="research-goals" className="py-24 bg-zinc-950/45 border-y border-zinc-900 backdrop-blur-[1px]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full border border-zinc-800 bg-black text-cyan-400 text-xs font-semibold uppercase tracking-widest mb-4">
            05 // Research Goals
          </div>
          <h2 className="text-3xl sm:text-5xl font-bold text-white mb-4">Current Direction</h2>
          <p className="text-lg text-zinc-400">
            A concise summary of my present academic focus, technical growth, and long-term research objective.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {TESTIMONIALS.map((item) => (
            <div key={item.id} className="rounded-3xl border border-zinc-800 bg-black p-8 text-left">
              <Quote className="w-8 h-8 text-yellow-400 mb-5" />
              <p className="text-zinc-300 leading-relaxed mb-6">{item.content}</p>
              <div className="pt-4 border-t border-zinc-800">
                <h3 className="text-white font-semibold">{item.name}</h3>
                <p className="text-sm text-cyan-400">{item.role}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
