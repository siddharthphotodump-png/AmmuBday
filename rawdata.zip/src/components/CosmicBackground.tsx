import React, { useEffect, useMemo, useState } from 'react';

type Star = {
  id: number;
  x: number;
  y: number;
  size: number;
  opacity: number;
  depth: number;
  color: 'white' | 'cyan' | 'gold';
  delay: number;
  duration: number;
};

type Moon = {
  id: number;
  x: number;
  y: number;
  size: number;
  depth: number;
  tint: 'white' | 'cyan' | 'gold';
  ring: boolean;
  glow: number;
};

const createSeededValue = (seed: number) => {
  const x = Math.sin(seed * 999) * 10000;
  return x - Math.floor(x);
};

export const CosmicBackground: React.FC = () => {
  const [mouse, setMouse] = useState({ x: 0, y: 0 });
  const [scrollY, setScrollY] = useState(0);

  const stars = useMemo<Star[]>(() => {
    return Array.from({ length: 120 }, (_, i) => {
      const x = createSeededValue(i + 1) * 100;
      const y = createSeededValue(i + 201) * 100;
      const size = 1 + createSeededValue(i + 401) * 2.6;
      const opacity = 0.18 + createSeededValue(i + 601) * 0.72;
      const depth = 4 + createSeededValue(i + 801) * 20;
      const duration = 2.8 + createSeededValue(i + 1001) * 4.5;
      const delay = createSeededValue(i + 1201) * 5;
      const colorPick = createSeededValue(i + 1401);
      const color: Star['color'] = colorPick > 0.82 ? 'gold' : colorPick > 0.62 ? 'cyan' : 'white';

      return {
        id: i,
        x,
        y,
        size,
        opacity,
        depth,
        color,
        delay,
        duration,
      };
    });
  }, []);

  const moons = useMemo<Moon[]>(() => {
    return [
      {
        id: 1,
        x: 10,
        y: 14,
        size: 180,
        depth: 14,
        tint: 'gold',
        ring: false,
        glow: 0.18,
      },
      {
        id: 2,
        x: 83,
        y: 20,
        size: 120,
        depth: 18,
        tint: 'cyan',
        ring: true,
        glow: 0.14,
      },
      {
        id: 3,
        x: 72,
        y: 78,
        size: 90,
        depth: 12,
        tint: 'white',
        ring: false,
        glow: 0.1,
      },
    ];
  }, []);

  useEffect(() => {
    const handleMouseMove = (event: MouseEvent) => {
      setMouse({ x: event.clientX, y: event.clientY });
    };

    const handleScroll = () => {
      setScrollY(window.scrollY);
    };

    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('scroll', handleScroll, { passive: true });

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  const viewportWidth = typeof window !== 'undefined' ? window.innerWidth : 1440;
  const viewportHeight = typeof window !== 'undefined' ? window.innerHeight : 900;
  const mouseX = viewportWidth ? mouse.x / viewportWidth - 0.5 : 0;
  const mouseY = viewportHeight ? mouse.y / viewportHeight - 0.5 : 0;

  const starColor = (color: Star['color']) => {
    if (color === 'gold') return 'rgba(234, 179, 8, 0.95)';
    if (color === 'cyan') return 'rgba(34, 211, 238, 0.9)';
    return 'rgba(255, 255, 255, 0.95)';
  };

  const moonPalette = (tint: Moon['tint']) => {
    if (tint === 'gold') {
      return {
        fill: 'rgba(234, 179, 8, 0.08)',
        border: 'rgba(234, 179, 8, 0.28)',
        shadow: 'rgba(234, 179, 8, 0.16)',
      };
    }

    if (tint === 'cyan') {
      return {
        fill: 'rgba(34, 211, 238, 0.07)',
        border: 'rgba(34, 211, 238, 0.24)',
        shadow: 'rgba(34, 211, 238, 0.14)',
      };
    }

    return {
      fill: 'rgba(255, 255, 255, 0.05)',
      border: 'rgba(255, 255, 255, 0.16)',
      shadow: 'rgba(255, 255, 255, 0.1)',
    };
  };

  return (
    <div className="pointer-events-none fixed inset-0 overflow-hidden" aria-hidden="true">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(255,255,255,0.02),transparent_60%)]" />

      {stars.map((star) => {
        const translateX = mouseX * star.depth;
        const translateY = mouseY * star.depth + (scrollY * star.depth) / 260;
        const color = starColor(star.color);

        return (
          <span
            key={star.id}
            className="cosmic-star absolute rounded-full"
            style={{
              left: `${star.x}%`,
              top: `${star.y}%`,
              width: `${star.size}px`,
              height: `${star.size}px`,
              opacity: star.opacity,
              backgroundColor: color,
              boxShadow: `0 0 ${star.size * 8}px ${color}`,
              transform: `translate3d(${translateX}px, ${translateY}px, 0)`,
              animationDuration: `${star.duration}s`,
              animationDelay: `${star.delay}s`,
            }}
          />
        );
      })}

      {moons.map((moon) => {
        const palette = moonPalette(moon.tint);
        const translateX = mouseX * moon.depth;
        const translateY = mouseY * moon.depth + (scrollY * moon.depth) / 380;

        return (
          <div
            key={moon.id}
            className="cosmic-moon absolute rounded-full"
            style={{
              left: `${moon.x}%`,
              top: `${moon.y}%`,
              width: `${moon.size}px`,
              height: `${moon.size}px`,
              transform: `translate3d(${translateX}px, ${translateY}px, 0)`,
              background: `radial-gradient(circle at 35% 35%, rgba(255,255,255,0.1), ${palette.fill} 45%, rgba(0,0,0,0) 100%)`,
              border: `1px solid ${palette.border}`,
              boxShadow: `0 0 ${moon.size * moon.glow}px ${palette.shadow}`,
            }}
          >
            <div
              className="absolute inset-[18%] rounded-full border"
              style={{ borderColor: palette.border, opacity: 0.4 }}
            />
            <div
              className="absolute inset-[34%] rounded-full border"
              style={{ borderColor: palette.border, opacity: 0.25 }}
            />
            {moon.ring && (
              <div
                className="absolute left-1/2 top-1/2 w-[132%] h-[38%] -translate-x-1/2 -translate-y-1/2 rounded-full border"
                style={{ borderColor: palette.border, opacity: 0.35 }}
              />
            )}
          </div>
        );
      })}

      <div className="absolute inset-0 bg-[radial-gradient(circle_at_top,rgba(255,255,255,0.035),transparent_28%),radial-gradient(circle_at_bottom,rgba(34,211,238,0.03),transparent_22%)]" />
    </div>
  );
};

export default CosmicBackground;
