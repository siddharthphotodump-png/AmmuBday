import React, { useState, useMemo } from 'react';
import { PROJECTS_DATA, Project } from '../data/portfolioData';
import { ExternalLink, FileText } from 'lucide-react';

interface ProjectsProps {
  onSelectProject: (project: Project) => void;
}

export const Projects: React.FC<ProjectsProps> = ({ onSelectProject }) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const categories = ['All', 'Research', 'Simulation', 'Astronomy', 'Data'];

  const filteredProjects = useMemo(() => {
    if (selectedCategory === 'All') return PROJECTS_DATA;
    return PROJECTS_DATA.filter((p) => p.category === selectedCategory);
  }, [selectedCategory]);

  return (
    <section id="projects" className="py-24 border-t border-zinc-900 bg-black">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full border border-zinc-800 bg-zinc-950 text-cyan-400 text-xs font-semibold uppercase tracking-widest mb-4">
            03 // Research Highlights
          </div>
          <h2 className="text-3xl sm:text-5xl font-bold text-white mb-4">Selected Work & Research Focus</h2>
          <p className="text-lg text-zinc-400">
            A few key research themes, academic projects, and scientific areas I have worked on or studied closely.
          </p>
        </div>

        <div className="flex flex-wrap justify-center gap-2 mb-12">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-4 py-2 rounded-lg border text-sm transition-colors ${
                selectedCategory === cat
                  ? 'border-yellow-400 text-yellow-400 bg-zinc-950'
                  : 'border-zinc-800 text-zinc-400 bg-zinc-950 hover:text-white'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {filteredProjects.map((project) => (
            <div key={project.id} className="rounded-3xl border border-zinc-800 bg-zinc-950 overflow-hidden">
              <img src={project.image} alt={project.title} className="w-full h-56 object-cover" />
              <div className="p-6 text-left">
                <div className="text-xs uppercase tracking-wider text-cyan-400 mb-2">{project.category}</div>
                <h3 className="text-2xl font-semibold text-white mb-2">{project.title}</h3>
                <p className="text-zinc-300 mb-4">{project.tagline}</p>

                <div className="flex flex-wrap gap-2 mb-6">
                  {project.tags.map((tag, idx) => (
                    <span key={idx} className="px-2.5 py-1 rounded-full border border-zinc-800 text-xs text-zinc-400">
                      {tag}
                    </span>
                  ))}
                </div>

                <div className="flex items-center justify-between pt-4 border-t border-zinc-800">
                  <button
                    onClick={() => onSelectProject(project)}
                    className="inline-flex items-center gap-2 text-sm text-yellow-400 hover:text-yellow-300"
                  >
                    <FileText className="w-4 h-4" />
                    View details
                  </button>
                  <a href={project.demoUrl} className="inline-flex items-center gap-2 text-sm text-zinc-300 hover:text-white">
                    <ExternalLink className="w-4 h-4" />
                    Jump to section
                  </a>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
