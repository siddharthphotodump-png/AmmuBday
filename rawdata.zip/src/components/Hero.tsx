import React from 'react';
import { ArrowRight, BookOpen, Telescope, Orbit, Atom, Camera, ExternalLink } from 'lucide-react';
import { PERSONAL_INFO } from '../data/portfolioData';

export const Hero: React.FC = () => {
  return (
    <section className="relative min-h-screen pt-32 pb-20 flex items-center overflow-hidden">
      <div className="absolute inset-0 bg-grid-pattern opacity-30 pointer-events-none -z-10" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          <div className="lg:col-span-7 text-left">
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full border border-zinc-800 bg-zinc-950 text-cyan-400 text-xs font-semibold uppercase tracking-widest mb-6">
              <span className="w-2 h-2 rounded-full bg-cyan-400" />
              Physics Undergraduate Portfolio
            </div>

            <h2 className="text-lg sm:text-xl font-['Fira_Code',monospace] text-zinc-400 mb-3">
              Hello, I'm
            </h2>

            <h1 className="text-4xl sm:text-6xl lg:text-7xl font-bold text-white leading-tight mb-5">
              {PERSONAL_INFO.name}
            </h1>

            <p className="text-xl sm:text-2xl text-yellow-400 mb-6 font-medium">
              {PERSONAL_INFO.title}
            </p>

            <p className="text-lg text-zinc-300 max-w-3xl leading-relaxed mb-10">
              {PERSONAL_INFO.tagline}
            </p>

            <div className="flex flex-wrap gap-4 mb-10">
              <a
                href="#timeline"
                className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-white text-black font-semibold hover:bg-zinc-200 transition-colors"
              >
                View Timeline
                <ArrowRight className="w-4 h-4" />
              </a>
              <a
                href="#contact"
                className="inline-flex items-center gap-2 px-6 py-3 rounded-xl border border-zinc-800 bg-zinc-950 text-white font-semibold hover:border-cyan-400 hover:text-cyan-400 transition-colors"
              >
                Contact Me
              </a>
            </div>

            <div className="flex flex-wrap gap-3 text-sm text-zinc-300">
              <span className="px-3 py-1.5 rounded-full border border-zinc-800 bg-zinc-950">Astronomy</span>
              <span className="px-3 py-1.5 rounded-full border border-zinc-800 bg-zinc-950">Detector Physics</span>
              <span className="px-3 py-1.5 rounded-full border border-zinc-800 bg-zinc-950">FLUKA Simulation</span>
              <span className="px-3 py-1.5 rounded-full border border-zinc-800 bg-zinc-950">Observational Astrophysics</span>
            </div>
          </div>

          <div className="lg:col-span-5 flex flex-col gap-6">
            <div className="bg-zinc-950 border border-zinc-800 rounded-3xl p-8 shadow-2xl">
              <div className="flex items-center gap-4 mb-8">
                <div className="w-14 h-14 rounded-2xl bg-zinc-900 border border-zinc-800 flex items-center justify-center">
                  <Telescope className="w-7 h-7 text-yellow-400" />
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-white">Academic Snapshot</h3>
                  <p className="text-sm text-zinc-400">Current focus and direction</p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 mb-8">
                {PERSONAL_INFO.stats.map((stat, idx) => (
                  <div key={idx} className="rounded-2xl border border-zinc-800 bg-black p-4">
                    <div className="text-2xl font-bold text-white mb-1">{stat.value}</div>
                    <div className="text-xs uppercase tracking-wide text-zinc-500">{stat.label}</div>
                  </div>
                ))}
              </div>

              <div className="space-y-4 text-sm">
                <div className="flex items-center gap-3 text-zinc-300">
                  <BookOpen className="w-4 h-4 text-cyan-400" />
                  <span>Major in Physics, Minor in Mathematics</span>
                </div>
                <div className="flex items-center gap-3 text-zinc-300">
                  <Atom className="w-4 h-4 text-yellow-400" />
                  <span>Interested in detector physics and instrumentation</span>
                </div>
                <div className="flex items-center gap-3 text-zinc-300">
                  <Orbit className="w-4 h-4 text-cyan-400" />
                  <span>Goal: pursue research in observational astronomy</span>
                </div>
              </div>
            </div>

            <div className="rounded-2xl border border-zinc-800 bg-zinc-950 p-5 text-sm text-zinc-300">
              <span className="text-white font-semibold">Website:</span> {PERSONAL_INFO.website}
            </div>

            <div className="rounded-2xl border border-zinc-800 bg-zinc-950 p-5">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 rounded-xl border border-zinc-800 bg-black flex items-center justify-center">
                  <Camera className="w-5 h-5 text-yellow-400" />
                </div>
                <div>
                  <h3 className="text-white font-semibold">Photography</h3>
                  <p className="text-xs text-zinc-500">Astro and photo archives</p>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <a
                  href="https://astro.verse.qzz.io"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center justify-center gap-2 rounded-xl border border-zinc-800 bg-black px-4 py-3 text-sm font-semibold text-cyan-400 hover:border-cyan-400 transition-colors"
                >
                  Astroverse
                  <ExternalLink className="w-4 h-4" />
                </a>
                <a
                  href="https://photo.verse.qzz.io"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center justify-center gap-2 rounded-xl border border-zinc-800 bg-black px-4 py-3 text-sm font-semibold text-yellow-400 hover:border-yellow-400 transition-colors"
                >
                  Photoverse
                  <ExternalLink className="w-4 h-4" />
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
